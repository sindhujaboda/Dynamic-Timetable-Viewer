const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path'); // For serving static files

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Bk071204@',
    database: 'college_db',
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to the database.');
});

// Serve 'user.html' when accessing the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'user.html'));
});

// Fetch schedule based on basic filters (Year, Department, Section)
app.get('/getSchedule', (req, res) => {
    const { year, department, section } = req.query;

    // Validate the query parameters
    if (!year || !department || !section) {
        return res.status(400).json({ error: 'Parameters year, department, and section are required.' });
    }

    // SQL query to fetch schedule based on provided filters
    const query = `
        SELECT * FROM schedules 
        WHERE year = ? AND department = ? AND section = ?
    `;

    // Log query parameters for debugging
    console.log('Fetching schedule with params:', { year, department, section });

    db.query(query, [year, department, section], (err, result) => {
        if (err) {
            console.error('Error fetching schedule:', err);
            return res.status(500).json({ error: 'Failed to fetch schedule.' });
        }

        // Check if schedule is found
        if (result.length === 0) {
            return res.status(404).json({ error: 'No schedule found for the given parameters.' });
        }

        // Respond with the filtered schedule data
        res.status(200).json({
            message: `Schedule for ${year} - ${department} - ${section}`,
            schedule: result,
        });
    });
});

// Fetch all schedules
app.get('/getAllSchedules', (req, res) => {
    const query = 'SELECT * FROM schedules';

    db.query(query, (err, result) => {
        if (err) {
            console.error('Error fetching schedules:', err);
            return res.status(500).json({ error: 'Failed to fetch schedules.' });
        }

        res.status(200).json({
            message: 'All schedules fetched successfully.',
            schedules: result,
        });
    });
});

// Start the server
const port = 5000;
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
